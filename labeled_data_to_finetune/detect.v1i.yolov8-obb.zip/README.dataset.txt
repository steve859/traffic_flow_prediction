# detect > 2025-12-25 2:24pm
https://universe.roboflow.com/nguyen-hong-quan-koynt/detect-przzi

Provided by a Roboflow user
License: CC BY 4.0

